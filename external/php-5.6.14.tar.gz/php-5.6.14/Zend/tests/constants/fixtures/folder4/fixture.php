<?php
echo __DIR__ . "\n";
 echo dirname(__FILE__) . "\n";
